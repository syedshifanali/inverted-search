
#include "header.h"
#include <stddef.h>

int my_check_name(char* fname)
{
    char* str = strstr(fname, ".");
    if (str == NULL)
        return FAILURE;
    else
        return SUCCESS;
}

void my_validate_n_store_filenames(file_node_t** files_h, char* filenames[])
{
    int i = 1, ret;    
    my_printline();
    printf("\n");
    while (filenames[i] != NULL)
    {
    ret = my_IsFileValid(filenames[i]);
        if (ret == SUCCESS)
        {
            ret = my_IsFileDuplicate(filenames[i], files_h);
            if (ret == FAILURE)
            {
                ret = my_store_filenames_to_list(filenames[i], files_h);
                if (ret == SUCCESS)
                {
                    printf("The File %s is added to the List Successfully.\n", filenames[i]);
                }
            }
        }
        i += 1;
    }
    if (*files_h == NULL)
    {
        printf("There is no Valid File passed as Input.\n"
               "Please enter names of Valid Files only.\n");
        exit(0);
    }
    return;
}
int my_IsFileValid(char* filename)
{
    FILE* fptr = fopen(filename, "r");
    if (fptr == NULL)
    {
        printf("The File %s is not present.\n", filename);
        return NOT_PRESENT;
    }
    else
    {
        fseek(fptr, 0L, SEEK_END);
        int pos = ftell(fptr);

        if (pos == 0)
        {
            printf("The File %s is an Empty File.\n", filename);
            return FILE_EMPTY;
        }
        else
        {
            fclose(fptr);
            return SUCCESS;
        }
    }
}

int my_IsFileDuplicate(char* filename, file_node_t** head)
{
    file_node_t* temp = *head;

    while (temp != NULL)
    {
        if ((strncmp(filename, temp->f_name, NAMELENGTH)) == 0)
        {
            printf("The File %s is repeated.\n", filename);
            return REPEATED;
        }
        
        temp = temp->link;
    }

    return FAILURE;
}

int my_store_filenames_to_list(char* f_name, file_node_t** head)
{
    int ret = my_insert_at_last_file(head, f_name);
    if (ret == FAILURE)
    {
        printf("Unable to add the File %s into the File List.\n", f_name);
        return FAILURE;
    }
    
    return SUCCESS;
}

int my_get_key(char f_char)
{
    if (isalpha(f_char))
    {
        f_char = (char) toupper(f_char);
        return (f_char % 65);
    }
    else if (isdigit(f_char))
    {
        return 26;
    }
    else
    {
        return 27;
    }
}

int my_check_word(char* word, main_node_t* head)
{
    while (head != NULL)
    {
        if (strncmp(head->word, word, BUFF_SIZE) == 0)
            return REPEATED;

        head = head->link;
    }

    return FAILURE;
}

int my_check_file(char* f_name, char* word, main_node_t* head)
{
    while (head != NULL)
    {
        if (strncmp(head->word, word, BUFF_SIZE) == 0)
        {
            sub_node_t* temp = head->sub_link;
            while (temp != NULL)
            {
                if (strncmp(temp->f_name, f_name, NAMELENGTH) == 0)
                    return REPEATED;
                
                temp = temp->link;
            }
        }

        head = head->link;
    }
    return FAILURE;
}