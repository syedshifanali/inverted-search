#include "header.h"

int my_display_DB(main_node_t** head)
{
    my_printline();
       printf("\n");
    int i = 0, flag = 0;

    while (i < SIZE)
    {
        if (head[i] != NULL)
        {
            my_display_words(head[i], i);
            flag = 1;
        }
        i += 1;
    }

    if (flag == 0)
    return FAILURE;
    else
    return SUCCESS;
}

void my_display_words(main_node_t* temp1, int index)
{
 
    while (temp1 != NULL)
    {
        printf("%s: ", temp1->word);
        my_display_files(temp1->sub_link);
        printf("\n");
        temp1 = temp1->link;
    }
}

void my_display_files(sub_node_t* temp2)
{
    int first = 1;
    while (temp2 != NULL)
    {
        if (!first) printf(", ");
        printf("%s[%d]", temp2->f_name, temp2->w_count);
        first = 0;
        temp2 = temp2->link;
    }
}