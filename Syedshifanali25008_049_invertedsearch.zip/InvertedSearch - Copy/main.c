#include "header.h"
/*
Name-Syed shifan ali
Batch-25008_049
Project name-Inverted search
*/
int main (int argc, char* argv [])
{
    if (argc < 2){
        printf ("Invalid number of Arguments.\n");
        printf ("Correct Usage ./a.out <file.txt> <file1.txt> ...\n");
    }else{
    my_command_handler (argv);
    }
    return 0;
}
int my_command_handler (char* argv [])
{
    file_node_t* files_H = NULL;
    main_node_t* HT [SIZE] = {NULL};
    int ret, option, flag = 0;
    char choice;

    my_validate_n_store_filenames (&files_H, argv);

    do {
        my_printline();
        printf("\n");
        printf("\t\tWelcome to Inverted Search Project \n");
        my_printline();
        printf("\n");
        printf ("1. Create Database\n2. Display Database\n3. Search Database\n4. Update Database\n5. Save Database\n");
        printf("Enter your choice [1-5]: ");

        if (scanf ("%d", &option) != 1)   
        {
            while (getchar() != '\n'); 
            printf("\nInvalid Choice. Please enter a number between 1 to 5.\n");
        }
        else
        {
            switch (option)
            {
                case 1:        
                    if (flag == 0)
                    {
                        ret = my_create_DB (files_H, HT);
                        if (ret == SUCCESS)
                        {
                            printf ("Database Created Successfully.\n");
                            my_printline();
                        }
                        flag = 1;
                    }
                    else
                    {
                        printf ("Create Database can only be called once at program start.\n");
                    }
                    break;
                case 2:
                    ret = my_display_DB (HT);
                    if (ret == FAILURE)
                    {
                        printf ("The Database is Empty.\n");
                    }else{
                        my_printline();
                        printf("\nDatabase Displayed Successfully!\n");
                        my_printline();
                    }
                    break;
                case 3:
                {
                    char word[BUFF_SIZE];
                    printf("Enter the word to search: ");
                    scanf("%s", word);
                    int key = my_get_key(word[0]);
                    if (HT[key] != NULL) {
                        if (my_search_word(HT, word) != SUCCESS) {
                            printf("No match found for the word '%s'.\n", word);
                        }
                    } else {
                        printf("No match found for the word '%s'.\n", word);
                    }
                }
                break;
                
                case 4:
                {
                    char fname[NAMELENGTH];
                    printf("Enter the file name to update: ");
                    scanf("%s", fname);
                    if (my_update_DB(&files_H, HT, fname) == SUCCESS) {
                        printf("Database updated successfully for file: %s\n", fname);
                    } else {
                        printf("Failed to update database for file: %s\n", fname);
                    }
                }
                break;
                case 5:
                {
                    char fname[NAMELENGTH];
                    printf("Enter the file name to save database: ");
                    scanf("%s", fname);
                    if (my_save_DB(HT, fname) == SUCCESS) {
                        printf("Database saved successfully to file: %s\n", fname);
                    } else {
                        printf("Failed to save database to file: %s\n", fname);
                    }
                }
                break;
                default:
                    printf ("Invalid Choice. Please enter a number between 1 to 5.\n");
            }
        }
        printf ("\nDo you want to Continue? [y / n]: ");
        scanf (" %c", &choice);
        getchar();
    } while ((choice == 'y'));
    printf("Thank you for using the Inverted Search Project. Goodbye! \n");
    return SUCCESS;
}

int my_insert_at_last_file (file_node_t** head, char* f_name)
{
    file_node_t* new = (file_node_t*) malloc (sizeof (file_node_t));
    if (new == NULL)
        return FAILURE;

    strncpy (new->f_name, f_name, (strlen (f_name) + 1));
    new->link = NULL;

    if (*head == NULL)
    {
        *head = new;
        return SUCCESS;
    }

    file_node_t* temp = *head;
    while (temp->link != NULL)
    {
        temp = temp->link;
    }

    temp->link = new;

    return SUCCESS;
}

int my_insert_at_last_main (main_node_t** head, char* word, char* f_name)
{
    main_node_t* new = (main_node_t*) malloc (sizeof (main_node_t));
    if (new == NULL)
        return FAILURE;

    strncpy (new->word, word, (strlen (word) + 1));
    new->link = NULL;
    new->sub_link = my_create_sub_node (f_name);
    new->f_count = 1;

    if (*head == NULL)
    {
        *head = new;
        return SUCCESS;
    }

    main_node_t* temp = *head;
    while (temp->link != NULL)
    {
        temp = temp->link;
    }
    temp->link = new;
    return SUCCESS;
}

sub_node_t* my_create_sub_node (char* f_name)
{
    sub_node_t* new = (sub_node_t*) malloc (sizeof (sub_node_t));
    strncpy (new->f_name, f_name, (strlen (f_name) + 1));
    new->w_count = 1;
    new->link = NULL;
    return new;
}

void my_printline(){
    for(int i=0; i<80; i++){
        printf("-");
    }
}