#include "header.h"

/* To Save the Database into a given File
 * Input: Hash Table and File Name
 * Output: Saved File
 * Return Value: SUCCESS/FAILURE
 */

int my_save_DB(main_node_t **head, char *fname)
{
    char name[NAMELENGTH];
    strncpy(name, fname, NAMELENGTH);

    // Enforce .txt extension only
    int len = strlen(fname);
    if (len < 4 || strcmp(fname + len - 4, ".txt") != 0) {
        printf("ERROR: Save file name must end with .txt\n");
        return FAILURE;
    }

    FILE* fptr = fopen(name, "w");
    if (fptr == NULL)
    {
        printf("ERROR: Unable to open the File %s.\n", name);
        return FAILURE;
    }
    int i = 0;

    while (i < SIZE)
    {
        if (head[i] != NULL)
        {
            main_node_t* temp1 = head[i];
            fprintf(fptr, "#%d;\n", i);

            while (temp1 != NULL)
            {
                fprintf(fptr, "%s;", temp1->word);
                fprintf(fptr, "%d;", temp1->f_count);
                
                sub_node_t* temp2 = temp1->sub_link;
                
                while (temp2 != NULL){
                    fprintf(fptr, "%s;", temp2->f_name);
                    fprintf(fptr, "%d;", temp2->w_count);
                    temp2 = temp2->link;
                }

                fprintf(fptr, "#\n");
                temp1 = temp1->link;
            }
        }
        i += 1;
    }

    fclose(fptr);
    return SUCCESS;
}

/* To Check whether the given File Name has an Extension or not
 * Input: Given File Name
 * Output: NIL
 * Return Value: SUCCESS/FAILURE
 */

int check_name(char* fname)
{
    char* str = strstr(fname, ".");
    if (str == NULL)
        return FAILURE;
    else
        return SUCCESS;
}